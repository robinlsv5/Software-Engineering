//
// Created by robinbakker on 25-9-2018.
//

#ifndef OPDRACHT_2_CALCULATOR_H
#define OPDRACHT_2_CALCULATOR_H


class Calculator {
public:
    double add(double, double);
    int add(int, int);
    double subtract(double, double);
    int subtract(int, int);
    double multiply(double, double);
    int multiply(int, int);
    double divide(double, double);
    double divide(int, int);
    double square(double);
    double square(int);
};


#endif //OPDRACHT_2_CALCULATOR_H
